from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
import pandas as pd
import numpy as np
from sklearn.cluster import DBSCAN
from typing import List, Dict
import json

app = FastAPI()

# Enable CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Global variables to store data and clusters
accidents_df = None
clusters = None

def load_and_process_data():
    global accidents_df, clusters
    try:
        # Load the accidents data
        accidents_df = pd.read_csv('data/accidents.csv')

        
        # Extract coordinates for clustering
        coordinates = accidents_df[['latitude', 'longitude']].values
        
        # Perform DBSCAN clustering
        dbscan = DBSCAN(eps=0.01, min_samples=5)  # Adjust parameters as needed
        clusters = dbscan.fit_predict(coordinates)
        
        # Add cluster labels to the dataframe
        accidents_df['cluster'] = clusters
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error processing data: {str(e)}")

@app.on_event("startup")
async def startup_event():
    load_and_process_data()

@app.get("/blackspots")
async def get_blackspots():
    if accidents_df is None or clusters is None:
        raise HTTPException(status_code=500, detail="Data not loaded")
    
    # Get blackspots (clusters with more than 5 accidents)
    blackspots = []
    for cluster_id in set(clusters):
        if cluster_id != -1:  # Exclude noise points
            cluster_accidents = accidents_df[accidents_df['cluster'] == cluster_id]
            if len(cluster_accidents) >= 5:
                blackspot = {
                    "latitude": cluster_accidents['latitude'].mean(),
                    "longitude": cluster_accidents['longitude'].mean(),
                    "accident_count": len(cluster_accidents),
                    "cluster_id": int(cluster_id)
                }
                blackspots.append(blackspot)
    
    return blackspots

@app.post("/live-accident")
async def process_live_accident(accident: Dict):
    if accidents_df is None or clusters is None:
        raise HTTPException(status_code=500, detail="Data not loaded")
    
    try:
        # Extract coordinates from the live accident
        lat = float(accident.get('latitude'))
        lon = float(accident.get('longitude'))
        
        # Find the nearest cluster
        coordinates = accidents_df[['latitude', 'longitude']].values
        distances = np.sqrt(np.sum((coordinates - np.array([lat, lon]))**2, axis=1))
        nearest_cluster = clusters[np.argmin(distances)]
        
        return {
            "is_blackspot": nearest_cluster != -1,
            "cluster_id": int(nearest_cluster),
            "distance_to_nearest": float(np.min(distances))
        }
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Error processing live accident: {str(e)}")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
